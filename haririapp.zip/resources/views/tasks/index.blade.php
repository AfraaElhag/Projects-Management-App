@extends('layouts.app')

@section('content')
@include('layouts.header', ['title' =>  __('text.Tasks List')  ]) 

          
        
        <div class="card card-style">
            <div class="content mt-1 mb-2">
                @include('flash::message')

                @if($tasks->isEmpty())
                <div class=" mb-5 text-center mt-5 " style="height: 200px;vertical-align :middle ">
                    <h3 class="mt-5 mb-5">
                        {{ __('text.No Projects') }} </h3>
                </div>
                @else


                    @canany('isAdmin')
                    <a href="{{ route('tasks.create') }}" class="btn btn-m mt-4 mb-4 btn-full  border-highlight  color-black rounded-s text-uppercase font-900" >{{ __('text.Add New Task') }}</a>

                    @endcan
                    <h1 class="vcard-title text-capitalize font-18  color-highlight">{{ __('text.Milestone One') }}</h1>
                    @foreach($tasks->where('milestone_number','1')  as $task )
                    <a href="{{ route('tasks.edit', [$task->id]) }}" class="color-highlight">

                        <div class="row mb-2">
                            <div class="col-6 ">
                              
                                    <img src="{{ asset('images/dot.png') }}" width="15"  height="15" class="">
                              
                             
                                <span class="font-14 has-icon">{{$task->task}}</span>
                                

                               
                                
                            </div>
                            <div class="col-6 text-end">
                                
                                @if($task->responsible == 'senior designer')
                                <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Senior Designer') }}</span>
                                @elseif($task->responsible == 'junior designer')
                                <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Junior Designer') }}</span>
                                @elseif($task->responsible == 'admin')
                                <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> {{ __('text.Admin') }}</span> 
                                @elseif($task->responsible == 'customer service')
                                <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Customer Service') }}</span>
                                @elseif($task->responsible == 'Depatment manager')
                                <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Depatment Manager') }}</span>
                                @elseif($task->responsible == 'project manager')
                                <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Project Manager') }}</span>
                                @elseif($task->responsible == 'accountant')
                                <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Accountant') }}</span>
                                @endif

                            </div>
                        </div>
                        
             
                        <div class="divider"></div>
                    </a>
                    @endforeach	
			    </div>
		    </div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">{{ __('text.Milestone Two') }}</h1>
                @foreach($tasks->where('milestone_number','2')  as $task )
                <a href="{{ route('tasks.edit', [$task->id]) }}" class="color-highlight">

                    <div class="row mb-0">
                        <div class="col-6">
                            <img src="{{ asset('images/dot.png') }}" width="15"  height="15" class="">

                            <span class="font-14 has-icon">{{$task->task}}</span>
                            
                        </div>
                        <div class="col-6 text-end">
                            @if($task->responsible == 'senior designer')
                            <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Senior Designer') }}</span>
                            @elseif($task->responsible == 'junior designer')
                            <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Junior Designer') }}</span>
                            @elseif($task->responsible == 'admin')
                            <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> {{ __('text.Admin') }}</span> 
                            @elseif($task->responsible == 'customer service')
                            <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Customer Service') }}</span>
                            @elseif($task->responsible == 'Depatment manager')
                            <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Depatment Manager') }}</span>
                            @elseif($task->responsible == 'project manager')
                            <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Project Manager') }}</span>
                            @elseif($task->responsible == 'accountant')
                            <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Accountant') }}</span>
                            @endif

                        </div>
                    </div>

                  
                    <div class="divider"></div>
                </a>
                @endforeach	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">{{ __('text.Milestone Three') }}</h1>
                @foreach($tasks->where('milestone_number','3')  as $task )
                <a href="{{ route('tasks.edit', [$task->id]) }}" class="color-highlight">

                    <div class="row mb-0">
                        <div class="col-6">
                            <img src="{{ asset('images/dot.png') }}" width="15"  height="15" class="">

                            <span class="font-14 has-icon">{{$task->task}}</span>
                        </div>
                        <div class="col-6 text-end">
                            @if($task->responsible == 'senior designer')
                            <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Senior Designer') }}</span>
                            @elseif($task->responsible == 'junior designer')
                            <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Junior Designer') }}</span>
                            @elseif($task->responsible == 'admin')
                            <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> {{ __('text.Admin') }}</span> 
                            @elseif($task->responsible == 'customer service')
                            <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Customer Service') }}</span>
                            @elseif($task->responsible == 'Depatment manager')
                            <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Depatment Manager') }}</span>
                            @elseif($task->responsible == 'project manager')
                            <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Project Manager') }}</span>
                            @elseif($task->responsible == 'accountant')
                            <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Accountant') }}</span>
                            @endif
                        </div>
                    </div>

                    <div class="divider"></div>
                </a>
                @endforeach	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">{{ __('text.Milestone Four') }}</h1>
                @foreach($tasks->where('milestone_number','4')  as $task )
                <a href="{{ route('tasks.edit', [$task->id]) }}" class="color-highlight">

                    <div class="row mb-0">
                        <div class="col-6">
                            
                            <img src="{{ asset('images/dot.png') }}" width="15"  height="15" class="">

                            <span class="font-14 has-icon">{{$task->task}}</span>
                        </div>
                        <div class="col-6 text-end">
                            @if($task->responsible == 'senior designer')
                            <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Senior Designer') }}</span>
                            @elseif($task->responsible == 'junior designer')
                            <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Junior Designer') }}</span>
                            @elseif($task->responsible == 'admin')
                            <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> {{ __('text.Admin') }}</span> 
                            @elseif($task->responsible == 'customer service')
                            <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Customer Service') }}</span>
                            @elseif($task->responsible == 'Depatment manager')
                            <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Depatment Manager') }}</span>
                            @elseif($task->responsible == 'project manager')
                            <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;">{{ __('text.Project Manager') }}</span>
                            @elseif($task->responsible == 'accountant')
                            <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;">{{ __('text.Accountant') }}</span>
                            @endif
                        </div>
                    </div>

                  
                    <div class="divider"></div>
                </a>
                @endforeach	
                @endif
			</div>
		</div>
		
		
        
    
      
        @endsection

<script type="text/javascript" src="scripts/bootstrap.min.js"></script>
<script type="text/javascript" src="scripts/custom.js"></script>

