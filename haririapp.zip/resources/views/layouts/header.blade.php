
        <div class="page-title page-title-small">
			<div class="row ">
                
                <div class="col-2  align-middle " style="">
                        <a href="#" data-menu="menu-main" class="preload-img" data-src="{{ asset('images/icons8-menu-50.png') }}"
                        style="  
                    border-radius: 0px; 
                    right:0px;
					margin-top:0px;
                       "></a>
                </div>
				<div class="col-8  align-middle text-center"  style="" >
					<h2>	{{$title}}</h2>
						
					</div>
                
                    
                <div class="col-2 text-end" style="position: absolute;left:0px;">
                    <h2><a href="#" data-back-button style="padding-left: 0px !important" ><i class="fa fa-arrow-left " style=""></i></a></h2>
                </div>
             </div>
   
		</div>

        <div class="card header-card shape-rounded" data-card-height="150">
            <div class="card-overlay bg-highlight opacity-95"></div>
            <div class="card-overlay dark-mode-tint"></div>
            <div class="card-bg preload-img" data-src="images/pictures/20s.jpg"></div>
        </div>