    


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Users List')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
     

        
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
        <div class="content position-relative" style="margin-bottom:-50px; z-index:99;">
			<div class="search-box position-relative shadow-xl border-0 bg-white rounded-m">
				
                <form method="POST"  action="">
                   
                    <button disabled><i class="fa fa-search ms-n3"></i></button>
				<input type="text" class="border-0" id="search" autocomplete="off" placeholder="<?php echo e(__('text.Search')); ?> " data-search name="q">
                </form>
			</div>
       

            <div class="search-results disabled-search-list card card-style mx-0 px-3 mt-4" style="margin-bottom:80px;" id="result">
				<div class="list-group list-custom-large">
                
					
				</div>
			</div>
        

            
		
		</div>
        <?php endif; ?>

            
		</div>

        
        <div class="card card-style mt-2 " style="min-height:60vh!important; ">
            <div class="content mb-2 ">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-m mt-1 mb-4 btn-full  border-highlight  color-black rounded-s text-uppercase font-900" ><?php echo e(__('text.Add New User')); ?></a>

            <?php endif; ?>

             <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <a href="<?php echo e(route('users.edit', [$user->id])); ?>">

                <div class="d-flex mb-3" id="user<?php echo e($user->id); ?>">
                    <div class="align-self-center">
                        <img src="images/avatars/5s.png" class="me-3 rounded-circle shadow-l bg-fade-red-dark" width="50">
                    </div>
                    <div class="ps-2 ms-1 align-self-center w-100">
                        <h5 class="font-500 mb-1"><?php echo e($user->name); ?> 
                            <span class="badge bg-red-dark   mt-0 p-1 font-12 font-400"  >
                                <?php if( $user->role == 'admin'): ?>
                                <?php echo e(__('text.Admin')); ?>

                                <?php elseif($user->role == 'senior designer'): ?>
                                <?php echo e(__('text.Senior Designer')); ?>

                                <?php elseif($user->role == 'junior designer'): ?>
                                <?php echo e(__('text.Junior Designer')); ?>

                                <?php elseif($user->role == 'customer service'): ?>
                                <?php echo e(__('text.Customer Service')); ?>

                                <?php elseif($user->role == 'accountant'): ?>
                                <?php echo e(__('text.Accountant')); ?>

                                <?php elseif($user->role == 'department manager'): ?>
                                <?php echo e(__('text.Department Manager')); ?>

                                <?php elseif($user->role == 'project manager'): ?>
                                <?php echo e(__('text.Project Manager')); ?>


                                 <?php endif; ?>
                            </span>
                        </h5>
                        <p class="mt-n1 font-11 mb-0"> <?php echo e($user->email); ?> </p>
                        <p class="mt-n1 font-11 mb-0"> <?php echo e($user->phone); ?></p>

                                    
                                        
                                            
                    </div> 
                </div>
                              
               
                        
                <div class="divider mb-3"></div>
             </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                
              
     

                
            


        <?php if($users  and $users->hasPages() ): ?>
        <nav aria-label="pagination-demo">
            <ul class="pagination justify-content-center"  style="padding-right: 0px !important">
				<?php if($users->onFirstPage()): ?>
                <li class="page-item">
                    <a class="page-link rounded-xs bg-highlight color-white border-0" href="#" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-right"></i></a>
                </li>
				<?php else: ?> 
				<li class="page-item">
                    <a class="page-link rounded-xs bg-highlight color-white border-0" href="<?php echo e($users->previousPageUrl()); ?>" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-right"></i></a>
                </li>
				<?php endif; ?>

				<?php
					if($users->lastPage() <5)
					$length=$users->lastPage();
					else {
						$length=4;
					}
					
				?>
				<?php for($page = 1; $page <= $length; $page++): ?>
				<?php if($page == $users->currentPage()): ?>
				<a class="page-link rounded-xs bg-highlight color-white border-0" href="#" tabindex="-1" aria-disabled="true"><?php echo e($page); ?></a>

				<?php else: ?>
				<li class="page-item"><a class="page-link rounded-xs bg-highlight color-white border-0" href="<?php echo e($users->url($page)); ?>"><?php echo e($page); ?></a></li>

	
				<?php endif; ?>
			<?php endfor; ?>

			<?php if($users->hasMorePages()): ?>
			<li class="page-item">
				<a class="page-link rounded-xs bg-highlight color-white border-0" href="<?php echo e($users->nextPageUrl()); ?>" rel="next" ><i class="fa fa-angle-left"></i></a>

			</li>
		<?php else: ?>
			<li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
				<a class="page-link rounded-xs bg-highlight color-white border-0" href="#"><i class="fa fa-angle-left"></i></a>
			</li>
		<?php endif; ?>
			
                
            </ul>
        </nav>
<?php endif; ?>       
</div>
</div>
     
<?php $__env->stopSection(); ?>




    
   



<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>

<script>
 
     
    
$(document).ready(function(){
   
  

    var searchResult = document.getElementById('result');
    $('#search').on('keyup', function(){
            search();
        });

   
    function search(){
        var searchResult = document.getElementById('result');

        $(searchResult).html('');
         var keyword = $('#search').val();
        if(keyword != ''){
            searchResult.classList.remove('disabled-search-list');

            $.post('<?php echo e(route("usersearch")); ?>',
            {
                _token: $('meta[name="csrf-token"]').attr('content'),
                keyword:keyword
            },
            function(data){
                console.log(data);
                show_result(data);
                
            });
        }    
    }

    
    // show result with ajax
    function show_result(data){
        $(searchResult).html('');
        if(data.results.length <= 0)
        {
           $(searchResult).append(`<p> <?php echo e(__('text.No Results')); ?></p>`);
        }

        else
        {
            for(let i = 0; i < data.results.length; i++){
                $( searchResult ).append( `<a href="users/` +data.results[i].id+     `/edit "  style="line-height: 70px;
                color: #1f1f1f;
                font-weight: 500;
                font-size: 13px;
                border-bottom: solid 1px rgba(0, 0, 0, 0.05);">
                                    <span>` +data.results[i].name + `</span>
                                                                      
                                </a> `);   
            }
        }
    }
});

function deletefun(id){
    event.preventDefault(); 
                                swal({
  title: 'Are you sure?',
  text: 'Once deleted, you will not be able to recover!',
  
  buttons: true,
  dangerMode: true,
}).then((result) => {
                                    if (result) {
                                        document.getElementById('delete-form'+id).submit();
  } else {
    
  }
                                
                                    });
}


</script>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/users/index.blade.php ENDPATH**/ ?>