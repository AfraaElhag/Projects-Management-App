<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($task->id); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($task->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($task->updated_at); ?></p>
</div>

<!-- Task Field -->
<div class="col-sm-12">
    <?php echo Form::label('task', 'Task:'); ?>

    <p><?php echo e($task->task); ?></p>
</div>

<!-- Milestone Number Field -->
<div class="col-sm-12">
    <?php echo Form::label('milestone_number', 'Milestone Number:'); ?>

    <p><?php echo e($task->milestone_number); ?></p>
</div>

<!-- Responsible Field -->
<div class="col-sm-12">
    <?php echo Form::label('responsible', 'Responsible:'); ?>

    <p><?php echo e($task->responsible); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/tasks/show_fields.blade.php ENDPATH**/ ?>