<?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($message['overlay']): ?>
        <?php echo $__env->make('flash::modal', [
            'modalClass' => 'flash-modal',
            'title'      => $message['title'],
            'body'       => $message['message']
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <div class="alert text-center
                    alert-<?php echo e($message['level']); ?>

                    <?php echo e($message['important'] ? 'alert-important' : ''); ?>"
                    role="alert"
        >
            <?php if($message['important']): ?>
                <button type="button"
                        class="close"
                        data-dismiss="alert"
                        aria-hidden="true"
                >&times;</button>
            <?php endif; ?>

        <?php if($message['message'] =='User saved successfully.'): ?>
            <?php echo e(__('text.User saved successfully')); ?>

        <?php elseif($message['message'] =='User updated successfully.'): ?>
            <?php echo e(__('text.User updated successfully')); ?>

        <?php elseif($message['message'] =='User deleted successfully.'): ?>
            <?php echo e(__('text.User deleted successfully')); ?>

        <?php elseif($message['message'] =='User not found'): ?>
            <?php echo e(__('text.User not found')); ?>


        <?php elseif($message['message'] =='Project saved successfully.'): ?>
            <?php echo e(__('text.Project saved successfully')); ?>

        <?php elseif($message['message'] =='Project updated successfully.'): ?>
            <?php echo e(__('text.Project updated successfully')); ?>

        <?php elseif($message['message'] =='Project deleted successfully.'): ?>
            <?php echo e(__('text.Project deleted successfully')); ?>

        <?php elseif($message['message'] =='Project not found'): ?>
            <?php echo e(__('text.Project not found')); ?>


        <?php elseif($message['message'] =='Task saved successfully.'): ?>
            <?php echo e(__('text.Task saved successfully')); ?>

        <?php elseif($message['message'] =='Task updated successfully.'): ?>
            <?php echo e(__('text.Task updated successfully')); ?>

        <?php elseif($message['message'] =='Task deleted successfully.'): ?>
            <?php echo e(__('text.Task deleted successfully')); ?>

        <?php elseif($message['message'] =='Task not found'): ?>
            <?php echo e(__('text.Task not found')); ?>


        <?php elseif($message['message'] =='Client saved successfully.'): ?>
            <?php echo e(__('text.Client saved successfully')); ?>

        <?php elseif($message['message'] =='Client updated successfully.'): ?>
            <?php echo e(__('text.Client updated successfully')); ?>

        <?php elseif($message['message'] =='Client deleted successfully.'): ?>
            <?php echo e(__('text.Client deleted successfully')); ?>

        <?php elseif($message['message'] =='Client not found'): ?>
            <?php echo e(__('text.Client not found')); ?>

        <?php elseif($message['message'] =='not allowed'): ?>
            <?php echo e(__('text.Not Allowed')); ?>

        <?php elseif($message['message'] =='previous not completed'): ?>
            <?php echo e(__('text.previous not completed')); ?>    
        
        
        <?php endif; ?>
        
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e(session()->forget('flash_notification')); ?>

<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/vendor/flash/message.blade.php ENDPATH**/ ?>