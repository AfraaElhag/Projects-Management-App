<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Project Info')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      

        
       
         
             
        <div class="card card-style">
            <div class="content mb-0">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
                        
                <div class="row mb-2" style="">
                    
                    <div class="col-6" style="padding-left:4px !important; padding-right:4px !important; ">
                        <a href="<?php echo e(route('projects.edit' , $project->id)); ?>"
                             class="btn btn-s mt-1 mb-2 btn-full  border-highlight  color-black rounded-s text-uppercase font-900"
                             style="padding-left:4px !important; padding-right:4px !important; "  ><?php echo e(__('text.Edit')); ?></a>
                
                    </div>
                    <div class="col-6" style="padding-left:4px !important; padding-right:4px !important; ">
                        <a href="#" class="btn btn-s mt-1 mb-2 btn-full  border-highlight  color-black rounded-s text-uppercase font-900"
                        onclick="deletefun(<?php echo e($project->id); ?> , '<?php echo e(__('text.Continue')); ?>' )" style="padding-left:4px !important; padding-right:4px !important; ">
                        <?php echo e(__('text.Delete Project')); ?>

                            <form id="delete-form<?php echo e($project->id); ?>" action="<?php echo e(route('projects.destroy',$project->id)); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form></a>
                
                    </div>
                   
                </div>
                <?php endif; ?>
               
             
              
                        
                    <h2 class="mt-4" >        
                        <?php echo e($project->project_name); ?>

                      <span class="badge bg-red-dark   p-1 font-14 font-400" " style="vertical-align: super;"><?php echo e($project->status); ?> %</span>
                    </h2>
                        
                  


               
               
                <p style="text-align: justify" class="mt-1">
                    <?php echo e($project->details); ?>

                </p>

                <p class="mb-2 mt-2 "><i class="fa fa-clock pe-2"></i><?php echo e(__('text.Start Date')); ?>&nbsp;&nbsp;
                    <?php echo date('Y-m-d', strtotime($project->start_date))?></p>
                <p class=" mb-2 mt-2"><i class="fa fa-clock pe-2"></i><?php echo e(__('text.End Date')); ?>  &nbsp;&nbsp; <?php echo date('Y-m-d', strtotime($project->end_date))?></p>
            
                
             

                <div class="divider mt-4"></div>

                <h3 class="font-700"><?php echo e(__('text.Client')); ?></h3>
                <p class="mb-2 mt-2"> <i class="fa fa-user pe-2"></i><?php echo e($project->client->name); ?>   </p>
                <p class="mb-2 mt-2"><i class="fa fa-suitcase pe-2"></i> <?php echo e($project->client->company_name); ?>   </p>
                <div class="divider mt-4"></div>

                <h3 class="font-700"><?php echo e(__('text.Project Team')); ?></h3>
                <?php if($project->users->isEmpty()): ?>
                <p class="font-14 mt-2 "><?php echo e(__('text.No Team Fonud')); ?> </p>
                        
                <?php else: ?>

                <?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-2">
                    <div class="col-6 " >
                        <p class="font-14 mt-2 "><?php echo e($user->name); ?><br><?php echo e($user->role); ?></p>
                        
                    </div>


                    <div class="col-6 mt-3">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
                        <a href="#"  class="btn btn-xxs mt-1 mb-2 btn-full  border-highlight  color-black rounded-s text-uppercase font-900"
                         href="#" onclick="deletefun(<?php echo e($user->id); ?> , '<?php echo e(__('text.Continue')); ?>')">   
                         <?php echo e(__('text.Delete')); ?>

                                    <form id="delete-form<?php echo e($user->id); ?>" action="<?php echo e(route('deletedesigner',$user->id)); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                                    </form>
                        </a>
                        
                        <?php endif; ?>
                        
                    </div>
                    
                    
                    </div>
               
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                    <?php endif; ?>

                <div class="divider mt-4"></div>

               
                 
                        <h3 ><?php echo e(__('text.Milestones')); ?></h3>
                   
                  
                 


              
                
                <?php $__currentLoopData = $project->projectStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('showprojecttasks', [$project->id,$milestone->milestone])); ?>" >
                    <?php endif; ?>
                    <?php if(Auth::guard('clientweb')->check()): ?>
                        <a href="<?php echo e(route('taskstimeline', [$project->id])); ?>" >
                    <?php endif; ?>
                   
                    
                <div class="card card-style mb-0 mt-4 
                <?php if($milestone->status == "100"): ?>
                bg-green-dark
                <?php elseif($milestone->status == "0" ): ?>
                 bg-fade-night-light
                <?php else: ?>
                bg-yellow-dark
                
                <?php endif; ?>
                    " 
                style="margin-left: 0px !important; margin-right:0px !important;margin-bottom:-15px !important; border-radius:10px;
                    box-shadow: 1px 1px 1px 1px rgb(0 0 0 / 10%);
                    border-bottom: solid 1px rgba(0, 0, 0, 0.05);">
                    
                        
                      
                            <div class="content row " style="margin-bottom:20px !important;">
                            <div class="col-8 " style="padding-right:0 !important">
                            <p class="font-17 font-700 color-white"> <?php if($milestone->milestone == '1'): ?>
                                <?php echo e(__('text.Milestone One')); ?><span class="font-22 font-600"> <?php echo e($milestone->status); ?> %</span>
                                <?php elseif($milestone->milestone== '2'): ?>
                                <?php echo e(__('text.Milestone Two')); ?><span class="font-22 font-600"> <?php echo e($milestone->status); ?> %</span>
                                <?php elseif($milestone->milestone == '3'): ?>
                                <?php echo e(__('text.Milestone Three')); ?> <span class="font-22 font-600"><?php echo e($milestone->status); ?> %</span>
                                <?php elseif($milestone->milestone == '4'): ?>
                                <?php echo e(__('text.Milestone Four')); ?><span class="font-22 font-600"> <?php echo e($milestone->status); ?> %</span>
                                <?php endif; ?>
                            </p>
                            </div>
                           <div class="col-4 text-end"  style="padding-right:0 !important">
                           <strong class="font-500 font-14">
                            <?php if($milestone->status == "100"): ?>
                            <?php echo e(__('text.Completed Project')); ?>

                            <?php elseif($milestone->status == "0" ): ?>
                            <?php echo e(__('text.Not Started')); ?>

                            <?php else: ?> 
                            <?php echo e(__('text.Inprogress')); ?>

                            <?php endif; ?>
                           </strong>
                            </div>
                        
                       

                    </div>
                </div>
            </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

               
                    
            <div class="mb-5"> </div>
                     
                    
                
                        
                
            </div>
        </div>

       
        <?php $__env->stopSection(); ?>




    
   



      
        <script type="text/javascript" src="<?php echo e(asset('ltr/scripts/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('ltr/scripts/custom.js')); ?>"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projects/show.blade.php ENDPATH**/ ?>