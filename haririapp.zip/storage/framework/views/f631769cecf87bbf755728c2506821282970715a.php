

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Tasks List')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

		<div class="card card-style">
           
            
			<div class="content mb-3" style="min-height:60vh!important; ">			
                    <div class="row mb-2">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-8 mt-1">
                         

                            <h1 class="">
    
                                <?php if($milestone == '1'): ?>
                            <?php echo e(__('text.Milestone One')); ?>

                            <?php elseif($milestone== '2'): ?>
                            <?php echo e(__('text.Milestone Two')); ?>

                            <?php elseif($milestone == '3'): ?>
                            <?php echo e(__('text.Milestone Three')); ?>

                            <?php elseif($milestone == '4'): ?>
                            <?php echo e(__('text.Milestone Four')); ?>

                            <?php endif; ?>
                            <span class="badge bg-red-dark   p-1 font-18 font-600" " style="vertical-align: super;">
                                <?php echo e($project->projectStatuses()->where('milestone',$milestone)->first()->status); ?> %</span>

                             </h1>
                        </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isDesigner'])): ?>
                    <div class="col-4 mb-3" style="padding-left:4px !important; padding-right:4px !important; ">
                       
                
                    </div>
                    <?php endif; ?>
    
                
                    
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isDesigner'])): ?>
                <a href="<?php echo e(route('editprojecttasks', [$project->id ,$task->id])); ?>" class="color-red-dark">
                    <?php endif; ?>
                    <div class="row mb-0 ">
                        <div class="col-8">
                            <span class="font-14"><?php echo e($task->task); ?></span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isDesigner'])): ?>
                            <?php if($task->pivot->status == 'completed'): ?>
                            <p class="mb-2 mt-2 "><i class="fa fa-clock pe-2"></i> <?php echo e(__('text.Completed Date')); ?>&nbsp;&nbsp;
                                <?php echo date('Y-m-d', strtotime($task->pivot->updated_at))?></p>
                            <p class="mb-2 mt-2 "><i class="fa fa-user pe-2"></i><?php echo e(__('text.Completed BY')); ?> &nbsp;&nbsp;
                                    <?php echo e($task->pivot->completed_by); ?></p>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="col-4 text-end">
                          
                            <?php if($task->pivot->status == 'completed'): ?>
                            <span class=" badge bg-green-dark     mt-0 p-1 font-12"> 
                                <?php echo e(__('text.Completed')); ?>

                            </span>
                               <?php else: ?>
                               <span class=" badge bg-red-dark    mt-0 p-1 font-12"> 
                                <?php echo e(__('text.Not Completed')); ?>

                             </span>
                                
                            
                            <?php endif; ?>
                            

                        </div>
                    </div>
                    <div class="divider"></div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        
		
		
        
    
      
        <?php $__env->stopSection(); ?>




    
   



      
        <script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projecttasks/show.blade.php ENDPATH**/ ?>