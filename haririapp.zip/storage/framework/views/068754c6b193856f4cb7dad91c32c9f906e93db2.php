<!-- Project Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('project_name', 'Project Name:'); ?>

    <?php echo Form::text('project_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::text('status', null, ['class' => 'form-control']); ?>

</div>

<!-- Start Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('start_date', 'Start Date:'); ?>

    <?php echo Form::text('start_date', null, ['class' => 'form-control','id'=>'start_date']); ?>

</div>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('#start_date').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- End Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('end_date', 'End Date:'); ?>

    <?php echo Form::text('end_date', null, ['class' => 'form-control','id'=>'end_date']); ?>

</div>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('#end_date').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- Details Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('details', 'Details:'); ?>

    <?php echo Form::text('details', null, ['class' => 'form-control']); ?>

</div><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projects/fields.blade.php ENDPATH**/ ?>