<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.New Project')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      


        <div class="card card-style">
           
       
            <div class="content mb-0">
                <p>
                </p>
                <form method="POST"  action="<?php echo e(route('projects.store')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <input type="hidden" value="<?php echo e($client_id); ?>" name="client_id">
                    <input type="hidden" value="0" name="status">

                <div class="input-style has-borders no-icon validate-field mb-4 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input type="name" value="<?php echo e(old('project_name')); ?>" class="form-control validate-name" id="form1" placeholder="<?php echo e(__('text.Project Name')); ?>" name="project_name">
                    <label for="form1" class="color-highlight"><?php echo e(__('text.Project Name')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>
                </div>
                <?php $__errorArgs = ['project_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            
              
                <div class="input-style has-borders  input-style-always-active no-icon mb-4">
                    <label for="form2" class="color-highlight "><?php echo e(__('text.Project Team')); ?></label>
                    <select id="form2" name="user_id[]" multiple aria-label="multiple" >
                        <option value="" disabled selected class="mt-2"><?php echo e(__('text.Select')); ?></option>
                        <?php $__currentLoopData = $designers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designer->id); ?>" class="mt-1" ><?php echo e($designer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </select>
                    <span><i class="fa fa-chevron-down"></i></span>
                    
                    <em></em>
                </div>

              

                <div class="input-style has-borders no-icon mb-4 input-style-always-active  <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input name="start_date" type="date" value="<?php echo date("Y-m-d"); ?>" max="2030-01-01" min="2021-01-01" class="form-control validate-text" id="form3" >
                    <label for="form3" class="color-highlight"><?php echo e(__('text.Start Date')); ?></label>
                    <i class="fa fa-check disabled valid me-4 pe-3 font-12 color-green-dark"></i>
                    <i class="fa fa-check disabled invalid me-4 pe-3 font-12 color-red-dark"></i>
                </div>
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="input-style has-borders no-icon mb-4 input-style-always-active <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input type="date" name="end_date" value="<?php echo date("Y-m-d"); ?>"  max="2030-01-01" min="2021-01-01" class="form-control validate-text" id="form4" >
                    <label for="form4" class="color-highlight"><?php echo e(__('text.End Date')); ?></label>
                    <i class="fa fa-check disabled valid me-4 pe-3 font-12 color-green-dark"></i>
                    <i class="fa fa-check disabled invalid me-4 pe-3 font-12 color-red-dark"></i>
                </div>
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="input-style has-borders no-icon mb-4">
                    <textarea id="form5" placeholder="<?php echo e(__('text.Details')); ?>" name="details" value="<?php echo e(old('details')); ?>"></textarea>
                    <label for="form5" class="color-highlight"><?php echo e(__('text.Details')); ?></label>
                    
                </div>


                <button class="btn-center-xl mb-3 btn btn-m btn-full rounded-sm shadow-l  border-highlight  color-black text-uppercase font-900 mt-4"><?php echo e(__('text.Save')); ?></button>

                </form>
            </div>
        </div>

       

      

        

        



        <?php $__env->stopSection(); ?>




    
   



      
<script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projects/create.blade.php ENDPATH**/ ?>