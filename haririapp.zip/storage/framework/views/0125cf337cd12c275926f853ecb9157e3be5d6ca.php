

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Milestones')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        
</div>
        
<div class=" mt-2 mb-5" style="min-height:60vh!important; ">
    <div class="content mb-2" >
        
        <div class="timeline-body timeline-body-center mt-n4">
            <div class="timeline-deco "></div>

            <?php $__currentLoopData = $project->projectStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($milestone->milestone  , [1,2,3])): ?>
            <div class="timeline-item text-center">
                
                <span class="badge bg-highlight shadow-l p-3 font-400 font-14" style="margin-bottom: -80px;
                margin-top: 40;"> 
                    <?php if($milestone->milestone == '1'): ?>
                    <?php echo e(__('text.Milestone One')); ?>

                    <?php elseif($milestone->milestone== '2'): ?>
                    <?php echo e(__('text.Milestone Two')); ?>

                    <?php elseif($milestone->milestone == '3'): ?>
                    <?php echo e(__('text.Milestone Three')); ?>

                    <?php elseif($milestone->milestone == '4'): ?>
                    <?php echo e(__('text.Milestone Four')); ?>

                    <?php endif; ?>
                </span>

                <?php $total=0; ?>
               
                <div class="timeline-item-content rounded-s shadow-l">
                    <?php $__currentLoopData = $tasks->where('milestone_number',$milestone->milestone); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                        <?php if($task->pivot->status == 'completed'): ?>
                        <?php $total=$total +1; ?>
                        
                        <?php endif; ?>

                    <div class="row mb-2 ">
                        <div class="col-8 text-start">
                            <span class="font-14"><?php echo e($task->task); ?></span>
                        </div>
                        <div class="col-4 text-end">
                          
                            <?php if($task->pivot->status == 'completed'): ?>
                                <span class=" badge bg-green-dark     mt-0 p-1 font-12"> 
                                    <?php echo e(__('text.Completed')); ?>

                                </span>
                            <?php else: ?>
                               <span class=" badge bg-red-dark    mt-0 p-1 font-12"> 
                                <?php echo e(__('text.Not Completed')); ?>

                             </span>
                            <?php endif; ?>
                            

                        </div>
                    </div>
                    <div class="divider"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php
                        $avg=intval(($total / $tasks->where('milestone_number',$milestone->milestone)->count()) * 100);
                    ?>
                    <div class="progress rounded-l" style="height:28px">
                        <div class="progress-bar  <?php if($avg == 100): ?>
                            bg-green-dark
                        <?php elseif($avg== 0 ): ?>
                            bg-fade-night-light
                        <?php else: ?>
                            bg-yellow-dark
                            
                            <?php endif; ?> 
                            text-start ps-3 color-white" 
                             role="progressbar" style="width: <?php echo e($avg); ?>%" 
                             aria-valuenow="10" aria-valuemin="0" 
                             aria-valuemax="100">
                             
                        </div>
                    </div>

                    <div class="mt-4 text-center">
                         <p class="icon icon-s rounded-circle 
                         <?php if($avg == 100): ?>
                            bg-green-dark
                        <?php elseif($avg == 0 ): ?>
                            bg-fade-night-light
                        <?php else: ?>
                            bg-yellow-dark
                            
                            <?php endif; ?>
                          p-2 font-16">
                          <?php echo e($avg); ?> %</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



          	
        </div>	
    </div></div>		

       
        <?php $__env->stopSection(); ?>




    
   



      
<script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projects/timeline.blade.php ENDPATH**/ ?>