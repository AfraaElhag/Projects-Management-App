<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($projectStatus->id); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($projectStatus->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($projectStatus->updated_at); ?></p>
</div>

<!-- Milestone Field -->
<div class="col-sm-12">
    <?php echo Form::label('milestone', 'Milestone:'); ?>

    <p><?php echo e($projectStatus->milestone); ?></p>
</div>

<!-- Status Field -->
<div class="col-sm-12">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo e($projectStatus->status); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/project_statuses/show_fields.blade.php ENDPATH**/ ?>