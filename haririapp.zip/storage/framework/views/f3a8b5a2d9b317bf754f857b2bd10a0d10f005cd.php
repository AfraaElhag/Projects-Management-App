

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Update Project Tasks')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        
      
<div class="card card-style">
    <div class="content mb-3">
		

				
                <?php if($task->pivot->status == 'completed'): ?>
                <span class=" badge bg-green-dark     mt-0 px-3 font-12"> 
                  <?php echo e(__('text.Completed')); ?>

                </span>
                   <?php else: ?>
                   <span class=" badge bg-red-dark    mt-0 p-3 font-12"> 
                     <?php echo e(__('text.Not Completed')); ?>

                 </span>
                 <?php endif; ?>

                
                      <p class="mb-5"><h4 class="font-400"><?php echo e($task->task); ?></h4> 
                                </p>
                                <?php if($task->pivot->status == 'completed'): ?>
                                <p class="mb-2 mt-2 "><i class="fa fa-clock pe-2"></i><?php echo e(__('text.Completed Date')); ?>&nbsp;&nbsp;
                                    <?php echo date('Y-m-d', strtotime($task->pivot->updated_at))?></p>
                                <p class="mb-4 mt-2 "><i class="fa fa-user pe-2"></i><?php echo e(__('text.Completed BY')); ?>  &nbsp;&nbsp;
                                        <?php echo e($task->pivot->completed_by); ?></p>
                                <?php endif; ?>          
                            
                      
                         


               
                
				
                    <form method="POST"  action="<?php echo e(route('updateprojecttasks',[$project->id , $task->id])); ?>" id="delete-form<?php echo e($task->id); ?>" >
                        <?php echo csrf_field(); ?>
                       <input type="hidden" name="milestone" value="<?php echo e($milestone); ?>">
                      
                   
                    <?php if($task->pivot->status == 'completed'): ?>
                    <input type="hidden" name="task_status" id="status<?php echo e($task->id); ?>" value="not completed" />
                    <?php else: ?>
                    <input type="hidden" name="task_status" id="status<?php echo e($task->id); ?>" value="completed"/>
                    <?php endif; ?>


                    
                    <a href="#" class="btn btn-s mt-1 mb-2 btn-full  border-highlight  color-black rounded-s text-uppercase font-700 "
                    onclick="deletefun(<?php echo e($task->id); ?> , '<?php echo e(__('text.Continue')); ?>')" style="padding-left:4px !important; padding-right:4px !important; ">
                    <?php if($task->pivot->status == 'completed'): ?>
                    <?php echo e(__('text.Mark AS Incomplete')); ?>

                   
                    <?php else: ?>
                    <?php echo e(__('text.Mark AS Complete')); ?>

                    
                    <?php endif; ?>
                       </a>
            
                     
    
                    </form>
             	
              
              
               

                
               
			</div>
		</div>

       
        
		
		
        
    
      
        <?php $__env->stopSection(); ?>




    
   



      
        <script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projecttasks/edit.blade.php ENDPATH**/ ?>