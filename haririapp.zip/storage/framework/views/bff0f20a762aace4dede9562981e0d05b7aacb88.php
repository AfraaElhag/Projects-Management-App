<!-- DataTable Bootstrap -->
<link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.bootstrap4.min.css">
<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/layouts/datatables_css.blade.php ENDPATH**/ ?>