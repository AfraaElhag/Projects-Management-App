  
    
   
    
    <div id="menu-main"
         class="menu menu-box-right menu-box-detached rounded-m"
         data-menu-width="260"
         
         data-menu-active="nav-welcome"
         data-menu-effect="menu-over"> 
       
        
        <div class="menu-logo text-center">
            <a href="#"><img class="rounded-circle bg-highlight" width="80" src="images/avatars/5s.png"></a>
            <h1 class="pt-3 font-800 font-28 text-uppercase">Azures</h1>
            <p class="font-11 mt-n2">Put a little <span class="color-highlight">color</span> in your life.</p>
        </div>
        
        <div class="menu-items mb-4">
            <h5 class="text-uppercase opacity-20 font-12 pl-3">Menu</h5>
            <a id="nav-welcome" href="index.html">
                <i data-feather="home" data-feather-line="1" data-feather-size="16" data-feather-color="blue-dark" data-feather-bg="blue-fade-light"></i>
                <span>Welcome</span>
                <em class="badge bg-highlight color-white">HOT</em>
                <i class="fa fa-circle"></i>
            </a>
            <a id="nav-starters" href="<?php echo e(route('users.index')); ?>">
                <i data-feather="star" data-feather-line="1" data-feather-size="16" data-feather-color="yellow-dark" data-feather-bg="yellow-fade-light"></i>
                <span>Starters</span>
                <i class="fa fa-circle"></i>
            </a>
            <a id="nav-features" href="<?php echo e(route('clients.index')); ?>">
                <i data-feather="heart" data-feather-line="1" data-feather-size="16" data-feather-color="red-dark" data-feather-bg="red-fade-light"></i>
                <span>Features</span>
                <i class="fa fa-circle"></i>
            </a>
            <a id="nav-pages" href="<?php echo e(route('tasks.index')); ?>">
                <i data-feather="file" data-feather-line="1" data-feather-size="16" data-feather-color="brown-dark" data-feather-bg="brown-fade-light"></i>
                <span>Pages</span>
                <i class="fa fa-circle"></i>
            </a>
            <a id="nav-media" href="index-media.html">
                <i data-feather="image" data-feather-line="1" data-feather-size="16" data-feather-color="green-dark" data-feather-bg="green-fade-light"></i>
                <span>Media</span>
                <i class="fa fa-circle"></i>
            </a>
            <a id="nav-shapes" href="index-shapes.html">
                <i data-feather="hexagon" data-feather-line="1" data-feather-size="16" data-feather-color="magenta-dark" data-feather-bg="magenta-fade-light"></i>
                <span>Shapes</span>
                <i class="fa fa-circle"></i>
            </a>
            <a href="#" data-submenu="sub-contact">
                <i data-feather="mail" data-feather-line="1" data-feather-size="16" data-feather-color="blue-dark" data-feather-bg="blue-fade-light"></i>
                <span>Contact</span>
                <strong class="badge bg-highlight color-white"></strong>
                <i class="fa fa-circle"></i>
            </a>
            <div id="sub-contact" class="submenu">
                <a href="contact.html" id="nav-contact"><i class="fa fa-envelope color-blue2-dark font-16 opacity-30"></i><span>Email</span><i class="fa fa-circle"></i></a>
                <a href="#"><i class="fa fa-phone color-green1-dark font-16 opacity-50"></i><span>Phone</span><i class="fa fa-circle"></i></a>
                <a href="#"><i class="fab fa-whatsapp color-whatsapp font-16 opacity-30"></i><span>WhatsApp</span><i class="fa fa-circle"></i></a>
            </div>
            <a id="nav-settings" href="index-settings.html">
                <i data-feather="settings" data-feather-line="1" data-feather-size="16" data-feather-color="gray-light" data-feather-bg="gray-fade-light"></i>
                <span>Settings</span>
                <i class="fa fa-circle"></i>
            </a>
            <a href="#" class="close-menu">
                <i data-feather="x" data-feather-line="3" data-feather-size="16" data-feather-color="red-dark" data-feather-bg="red-fade-dark"></i>
                <span>Close</span>
                <i class="fa fa-circle"></i>
            </a>
        </div>
        
        <div class="text-center">
            <a href="#" class="icon icon-xs mr-1 rounded-s bg-facebook"><i class="fab fa-facebook"></i></a>
            <a href="#" class="icon icon-xs mr-1 rounded-s bg-twitter"><i class="fab fa-twitter"></i></a>
            <a href="#" class="icon icon-xs mr-1 rounded-s bg-instagram"><i class="fab fa-instagram"></i></a>
            <a href="#" class="icon icon-xs mr-1 rounded-s bg-linkedin"><i class="fab fa-linkedin-in"></i></a>
            <a href="#" class="icon icon-xs rounded-s bg-whatsapp"><i class="fab fa-whatsapp"></i></a>
            <p class="mb-0 pt-3 font-10 opacity-30">Copyright <span class="copyright-year"></span> Enabled. All rights reserved</p>
        </div>
         
    </div>
    
    <!-- Be sure this is on your main visiting page, for example, the index.html page-->
    <!-- Install Prompt for Android -->
    <div id="menu-install-pwa-android" class="menu menu-box-bottom menu-box-detached rounded-l"
         data-menu-height="350" 
        data-menu-effect="menu-parallax">
        <div class="boxed-text-l mt-4">
            <img class="rounded-l mb-3" src="app/icons/icon-128x128.png" alt="img" width="90">
            <h4 class="mt-3">Azures on your Home Screen</h4>
            <p>
                Install Azures on your home screen, and access it just like a regular app. It really is that simple!
            </p>
            <a href="#" class="pwa-install btn btn-s rounded-s shadow-l text-uppercase font-900 bg-highlight mb-2">Add to Home Screen</a><br>
            <a href="#" class="pwa-dismiss close-menu color-gray2-light text-uppercase font-900 opacity-60 font-10">Maybe later</a>
            <div class="clear"></div>
        </div>
    </div>   

    <!-- Install instructions for iOS -->
    <div id="menu-install-pwa-ios" 
        class="menu menu-box-bottom menu-box-detached rounded-l"
         data-menu-height="320" 
        data-menu-effect="menu-parallax">
        <div class="boxed-text-xl mt-4">
            <img class="rounded-l mb-3" src="app/icons/icon-128x128.png" alt="img" width="90">
            <h4 class="mt-3">Azures on your Home Screen</h4>
            <p class="mb-0 pb-3">
                Install Azures on your home screen, and access it just like a regular app.  Open your Safari menu and tap "Add to Home Screen".
            </p>
            <div class="clear"></div>
            <a href="#" class="pwa-dismiss close-menu color-highlight font-800 opacity-80 text-center text-uppercase">Maybe later</a><br>
            <i class="fa-ios-arrow fa fa-caret-down font-40"></i>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/layouts/menu2.blade.php ENDPATH**/ ?>