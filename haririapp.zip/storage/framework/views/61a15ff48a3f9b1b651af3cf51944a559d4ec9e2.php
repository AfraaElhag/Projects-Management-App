<div class="table-responsive">
    <table class="table" id="projects-table">
        <thead>
        <tr>
            <th>Project Name</th>
        <th>Status</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Details</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->project_name); ?></td>
            <td><?php echo e($project->status); ?></td>
            <td><?php echo e($project->start_date); ?></td>
            <td><?php echo e($project->end_date); ?></td>
            <td><?php echo e($project->details); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['projects.destroy', $project->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('projects.show', [$project->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('projects.edit', [$project->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projects/table.blade.php ENDPATH**/ ?>