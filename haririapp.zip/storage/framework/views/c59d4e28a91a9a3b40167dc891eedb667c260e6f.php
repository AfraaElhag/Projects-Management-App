<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>