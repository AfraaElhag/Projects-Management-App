<!DOCTYPE HTML>
<?php if( app()->getLocale()== 'en'): ?>
<html lang="<?php echo e(app()->getLocale()); ?>" >
<?php else: ?>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="rtl"  >

<?php endif; ?>


<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<title>Alaa Hariri</title>

<?php if( app()->getLocale()== 'en'): ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('ltr/styles/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('ltr/styles/style.css')); ?>">
<?php else: ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('rtl/styles/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('rtl/styles/style.css')); ?>">

<?php endif; ?>
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/css/fontawesome-all.min.css')); ?>">    
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/css/all.css')); ?>">    


<link rel="manifest" href="<?php echo e(asset('_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
<link rel="apple-touch-icon" sizes="180x180" href="app/icons/icon-192x192.png">
<link rel="stylesheet"  type="text/css" href="<?php echo e(asset('rtl/styles/highlights/highlight_red.css')); ?>">
<link rel="stylesheet"  type="text/css" href="<?php echo e(asset('rtl/styles/highlights/highlight_dark.css')); ?>">

</head>

<body class="theme-light"  data-highlight="highlight_dark">

    <div id="preloader"><div class="spinner-border color-highlight" role="status"></div></div>
    
        <div id="page" >

            <!-- header and footer bar go here-->
          
           

            <div class="page-content" >
            <section >
                <?php echo $__env->yieldContent('content'); ?>
            </section>

            <!-- footer and footer card-->
            <div class="footer" >
                <div class="footer card card-style mx-0 mb-0 " >
                    <a href="#" class="footer-title pt-4 mb-2"><?php echo e(__('text.Follow Us')); ?></a>
                  
                   
                    <div class="text-center mb-3">
                        <a href="https://www.facebook.com/AlaaHaririarc/?eid=ARCewtqEQhgXPO4WsbLjy08zVfsQnquwt8a1eRhQnn7rm6QMAQ0cvY4apDo4a7zkWrZ81v9Zoe049Euf" class="icon icon-xs rounded-sm shadow-l me-1 bg-highlight"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://twitter.com/Alaahaririarc1" class="icon icon-xs rounded-sm shadow-l me-1 bg-highlight"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/alaahaririarc/?igshid=1dilwkib1rhqt" class="icon icon-xs rounded-sm shadow-l me-1 bg-highlight"><i class="fab fa-instagram"></i></a>

                    </div>
                </div>
                <div class="footer-card card shape-rounded bg-20" style="height:120px">
                    <div class="card-overlay bg-highlight opacity-90"></div>
                </div>
                    
            </div>  
        </div> 
    </div>

    
    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

<script type="text/javascript" src="<?php echo e(asset('https://code.jquery.com/jquery-1.7.1.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('scripts/custom.js')); ?>"></script>
<script src="<?php echo e(asset('https://unpkg.com/sweetalert/dist/sweetalert.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/layouts/app.blade.php ENDPATH**/ ?>