

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Alaa Hariri Office')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      



        <div class="card card-style">
            <div class="content mb-0">
                <div class="menu-logo text-center mt-3 mb-3">
                    <a href="#"><img class=" " width="80" src="<?php echo e(asset('images/logo.png')); ?>"></a>
                </div>
              <div class="list-group list-boxes mb-5 mt-5">
                    <a href="<?php echo e(route('login')); ?>" class="border border-highlight rounded-s shadow-xs">
                        <i class="fa fa-user "></i>
                        <span class="mt-0" ><?php echo e(__('text.Login As Employee')); ?></span>
                       
                        
                        
                    </a>

                    <a href="<?php echo e(route('clientlogin')); ?>" class="border border-highlight rounded-s shadow-xs">
                        
                        
                       
                        
                        <i class="fa fa-user "></i>
                        <span class="mt-0"><?php echo e(__('text.Login As Client')); ?></span>
                    </a>
                   
                </div>
            

            
               
                <div class="divider mt-4 mb-3"></div>

                
            </div>
            
        </div>

       
        <?php $__env->stopSection(); ?>




    
   



      
        <script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>
        
        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/prelogin.blade.php ENDPATH**/ ?>