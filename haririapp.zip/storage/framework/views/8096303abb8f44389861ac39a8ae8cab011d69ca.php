

<?php $__env->startSection('content'); ?>
        
        <div class="page-title page-title-small">
            <h2><a href="#" data-back-button><i class="fa fa-arrow-left"></i></a><?php echo e(__('text.Update Project Milestones')); ?></h2>
            <a href="#" data-menu="menu-main" class="bg-fade-highlight-light shadow-xl preload-img" data-src="images/avatars/5s.png"></a>
        </div>
        <div class="card header-card shape-rounded" data-card-height="150">
            <div class="card-overlay bg-highlight opacity-95"></div>
            <div class="card-overlay dark-mode-tint"></div>
            <div class="card-bg preload-img" data-src="images/pictures/20s.jpg"></div>
        </div>
		
		
		
		<div class="content mb-2">
			<h5 class="float-start font-16 font-500"><?php echo e(__('text.Update Project Milestones')); ?></h5>
			<a class="float-end font-12 color-highlight mt-n1" href="#">View All</a>
			<div class="clearfix"></div>
		</div>

		<form method="POST"  action="<?php echo e(route('updatemilestone',[$project->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

		<div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight"><?php echo e(__('text.Milestones')); ?></h1>
                <?php $__currentLoopData = $project->projectStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="form-check icon-check">
                    <?php if($milestone->status == 'completed'): ?>
					<input class="font-14 form-check-input" type="checkbox" value="<?php echo e($milestone->id); ?>" id="<?php echo e($milestone->id); ?>" checked name="milestone[]">
					<?php else: ?>
                    <input class="font-14 form-check-input" type="checkbox" value="<?php echo e($milestone->id); ?>" id="<?php echo e($milestone->id); ?>"  name="milestone[]">
                    <?php endif; ?>
                    <label class="font-14 form-check-label" for="<?php echo e($milestone->id); ?>">
                    <?php if($milestone->milestone == '1'): ?>
                    <?php echo e(__('text.Milestone One')); ?>

                    <?php elseif($milestone->milestone== '2'): ?>
                    <?php echo e(__('text.Milestone Two')); ?>

                    <?php elseif($milestone->milestone == '3'): ?>
                    <?php echo e(__('text.Milestone Three')); ?>

                    <?php elseif($milestone->milestone == '4'): ?>
                    <?php echo e(__('text.Milestone Four')); ?>

                    <?php endif; ?></label>
					<i class="font-17 icon-check-1 far fa-circle color-gray-dark"></i>
					<i class="font-17 icon-check-2 fa fa-check-circle color-green-dark"></i>
					
                </div>
                <div class="divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>
        <button class="mb-3 btn btn-m btn-full rounded-sm shadow-l bg-blue-dark text-uppercase font-900 mt-4"><?php echo e(__('text.Save')); ?></button>
        </form>
		
		
        
    
      
        <?php $__env->stopSection(); ?>




    
   



      
        <script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projectmilestones/edit.blade.php ENDPATH**/ ?>