        <div id="menu-main"
            class="menu menu-box-right menu-box-detached rounded-m"
            data-menu-width="260"
            data-menu-active="nav-welcome"
            data-menu-effect="menu-over"> 
        
        
        <div class="   mt-3  mb-3">
        <div class="row">
            <div >
                <a href="#" class="close-menu mx-4" style="">
                <i style="stroke-width: 5;" data-feather="x" data-feather-line="3" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                
                 </a>
            </div>
            <div class=" menu-logo text-center ">  
                          <a href="#"><img class=" " width="80" src="<?php echo e(asset('images/logo.png')); ?>"></a>
            </div>
        </div>
            
            
        </div>
        
        <div class="menu-items mb-4">
       
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
            <a id="nav-starters" href="<?php echo e(route('users.index')); ?>">
                
                <i data-feather="users" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Users')); ?> </span>
            </a>
            <a id="nav-features" href="<?php echo e(route('clients.index')); ?>">
                <i data-feather="users" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark" ></i>
                <span class="font-14"><?php echo e(__('text.Clients')); ?></span>
            </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
            <a id="nav-pages" href="<?php echo e(route('tasks.index')); ?>">
                <i data-feather="file" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Tasks')); ?></span>
            </a>
            <?php endif; ?>
            

            <?php if(auth()->guard()->check()): ?>
            <a id="nav-media" href="<?php echo e(route('projects.index')); ?>">
                <i data-feather="briefcase" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Projects')); ?></span>
            </a>
            <?php if(Auth::guard('clientweb')->check()): ?>

            <a id="nav-shapes" href="<?php echo e(route('clients.edit', Auth::user() )); ?>">
                <i data-feather="user" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Profile')); ?></span>
            </a>
            <?php else: ?>

            
            <a id="nav-shapes" href="<?php echo e(route('users.edit', Auth::user() )); ?>">
                <i data-feather="user" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Profile')); ?></span>
            </a>
            <?php endif; ?>
            <?php endif; ?>


            <?php if(Auth::guard('clientweb')->check() || Auth::guard('web')->check()): ?>
            
            <a id="nav-settings" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i data-feather="log-out" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Logout')); ?></span>
              
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
            </a>
            <?php else: ?>
            <a id="nav-settings" href="<?php echo e(route('prelogin')); ?> " ">
                <i data-feather="log-in" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Login')); ?></span>
              
                     
            </a>
            <?php endif; ?>
                
            
            <a id="nav-media" href="https://alaahariri.com/">
                <i data-feather="home" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.About US')); ?></span>
            </a>
            
            

            <a href="https://alaahariri.com/contact-us/" data-submenu="sub-contact">
                <i data-feather="mail" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14"><?php echo e(__('text.Contact Us')); ?></span>
            </a>
          

            

            <?php if( app()->getLocale()== 'en'): ?>
            <a id="nav-welcome" href="<?php echo e(route('lang','ar')); ?>">
                <i data-feather="globe" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14">AR </span>
                
            </a>
            <?php else: ?>
            <a id="nav-welcome" href="<?php echo e(route('lang','en')); ?>">
                <i data-feather="globe" data-feather-line="1" data-feather-size="20" data-feather-color="black" data-feather-bg="red-fade-dark"></i>
                <span class="font-14">EN </span>
            </a>
            <?php endif; ?>

           
        </div>
        
      
         
    </div>
    
    <!-- Be sure this is on your main visiting page, for example, the index.html page-->
    <!-- Install Prompt for Android -->
    <div id="menu-install-pwa-android" class="menu menu-box-bottom menu-box-detached rounded-l"
         data-menu-height="350" 
        data-menu-effect="menu-parallax">
        <div class="boxed-text-l mt-4">
            <img class="rounded-l mb-3" src="app/icons/icon-128x128.png" alt="img" width="90">
            <h4 class="mt-3">Azures on your Home Screen</h4>
            <p>
                Install Azures on your home screen, and access it just like a regular app. It really is that simple!
            </p>
            <a href="#" class="pwa-install btn btn-s rounded-s shadow-l text-uppercase font-900 bg-highlight mb-2">Add to Home Screen</a><br>
            <a href="#" class="pwa-dismiss close-menu color-gray2-light text-uppercase font-900 opacity-60 font-10">Maybe later</a>
            <div class="clear"></div>
        </div>
    </div>   

    <!-- Install instructions for iOS -->
    <div id="menu-install-pwa-ios" 
        class="menu menu-box-bottom menu-box-detached rounded-l"
         data-menu-height="320" 
        data-menu-effect="menu-parallax">
        <div class="boxed-text-xl mt-4">
            <img class="rounded-l mb-3" src="app/icons/icon-128x128.png" alt="img" width="90">
            <h4 class="mt-3">Azures on your Home Screen</h4>
            <p class="mb-0 pb-3">
                Install Azures on your home screen, and access it just like a regular app.  Open your Safari menu and tap "Add to Home Screen".
            </p>
            <div class="clear"></div>
            <a href="#" class="pwa-dismiss close-menu color-highlight font-800 opacity-80 text-center text-uppercase">Maybe later</a><br>
            <i class="fa-ios-arrow fa fa-caret-down font-40"></i>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/layouts/menu.blade.php ENDPATH**/ ?>