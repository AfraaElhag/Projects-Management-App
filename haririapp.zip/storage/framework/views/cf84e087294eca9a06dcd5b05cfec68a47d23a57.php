<!-- Task Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('task', 'Task:'); ?>

    <?php echo Form::text('task', null, ['class' => 'form-control']); ?>

</div>

<!-- Milestone Number Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('milestone_number', 'Milestone Number:'); ?>

    <?php echo Form::text('milestone_number', null, ['class' => 'form-control']); ?>

</div>

<!-- Responsible Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('responsible', 'Responsible:'); ?>

    <?php echo Form::text('responsible', null, ['class' => 'form-control']); ?>

</div><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/tasks/fields.blade.php ENDPATH**/ ?>