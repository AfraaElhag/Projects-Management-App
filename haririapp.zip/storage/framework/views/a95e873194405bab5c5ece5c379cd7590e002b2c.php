<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.New Task')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


        <div class="card card-style">
           
            <div class="content mb-0">
                <p>
                </p>
                <form method="POST"  action="<?php echo e(route('tasks.store')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="input-style has-borders no-icon validate-field mb-4 <?php $__errorArgs = ['task'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input type="name" value="<?php echo e(old('task')); ?>" class="form-control validate-name" id="form1" placeholder="<?php echo e(__('text.Task')); ?>" name="task">
                    <label for="form1" class="color-highlight"><?php echo e(__('text.Task')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>
                </div>
                <?php $__errorArgs = ['task'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            

                <div class="input-style has-borders no-icon mb-4 <?php $__errorArgs = ['responsible'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="form5" class="color-highlight"><?php echo e(__('text.Responsible')); ?></label>
                    <select id="form5" name="responsible">
                        <option value="default" disabled selected><?php echo e(__('text.Responsible')); ?></option>
                   

                        <option value="admin"><?php echo e(__('text.Admin')); ?></option>
                        <option value="senior designer"><?php echo e(__('text.Senior Designer')); ?></option>
                        <option value="junior designer"><?php echo e(__('text.Junior Designer')); ?></option>
                        <option value="customer service"><?php echo e(__('text.Customer Service')); ?></option>
                        <option value="department manager"><?php echo e(__('text.Depatment Manager')); ?></option>
                        <option value="project manager"><?php echo e(__('text.Project Manager')); ?></option>
                        <option value="accountant"><?php echo e(__('text.Accountant')); ?></option>



                    </select>
                    <span><i class="fa fa-chevron-down"></i></span>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <i class="fa fa-check disabled invalid color-red-dark"></i>
                    <em></em>
                </div>
                <?php $__errorArgs = ['responsible'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="input-style has-borders no-icon mb-4 <?php $__errorArgs = ['milestone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="form5" class="color-highlight"><?php echo e(__('text.Milestone')); ?></label>
                    <select id="form5" name="milestone_number">
                        <option value="default" disabled selected><?php echo e(__('text.Milestone')); ?></option>
                        <option value="1"><?php echo e(__('text.Milestone One')); ?></option>
                        <option value="2"><?php echo e(__('text.Milestone Two')); ?></option>
                        <option value="3"><?php echo e(__('text.Milestone Three')); ?></option>
                        <option value="4"><?php echo e(__('text.Milestone Four')); ?></option>
                    </select>
                    <span><i class="fa fa-chevron-down"></i></span>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <i class="fa fa-check disabled invalid color-red-dark"></i>
                    <em></em>
                </div>
                <?php $__errorArgs = ['milestone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="form-check icon-check">
                    <input class="form-check-input " type="checkbox" value="1" id="check3" name='client_viewable'>
                    <label class="form-check-label font-14" for="check3"><?php echo e(__('text.Client Viewable')); ?></label>
                    <i class="icon-check-1 far fa-square color-gray-dark font-16"></i>
                    <i class="icon-check-2 far fa-check-square font-16 color-highlight"></i>
                </div>


              

                <button class="btn-center-xl mb-3 btn btn-m btn-full rounded-sm shadow-l border-highlight  color-black text-uppercase font-900 mt-4"><?php echo e(__('text.Save')); ?></button>

                </form>
            </div>
        </div>

       

      

        

        


  



<?php $__env->stopSection(); ?>

<script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/tasks/create.blade.php ENDPATH**/ ?>