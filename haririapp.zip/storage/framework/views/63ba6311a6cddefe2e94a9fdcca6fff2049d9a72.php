<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Clients List')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
     
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>      

        <div class="content position-relative" style="margin-bottom:-50px; z-index:99;">
			<div class="search-box position-relative shadow-xl border-0 bg-white rounded-m">
				
                <form method="POST"  action="">
                   
                    <button disabled><i class="fa fa-search ms-n3"></i></button>
				<input type="text" class="border-0" id="search" autocomplete="off" placeholder="<?php echo e(__('text.Search')); ?>" data-search name="q">
                </form>
			</div>
       

            <div class="search-results disabled-search-list card card-style mx-0 px-3 mt-4" style="margin-bottom:80px;" id="result">
				<div class="list-group list-custom-large">
                    
					
					
				</div>
			</div>
        

           
		</div>
		<?php endif; ?>

            
		</div>
    

			<div class="card card-style mt-2 " style="min-height:60vh!important; ">
				<div class="content mb-2 ">
              
					<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					<?php if($clients->isEmpty()): ?>
			<div class=" mb-5 text-center mt-5 " style="height: 200px;vertical-align :middle ">
				<h3 class="mt-5 mb-5">
					<?php echo e(__('text.No Projects')); ?> </h3>
			</div>
			<?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
				<a href="<?php echo e(route('clients.create')); ?>" class="btn btn-m mt-1 mb-5 btn-full  border-highlight  color-black rounded-s text-uppercase font-900"><?php echo e(__('text.Add New Client')); ?></a>

                <?php endif; ?>
                
                
				<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('clients.show', [$client->id])); ?>">
					<div class="d-flex mb-3">
						<div class="align-self-center">
							<img src="images/avatars/5s.png" class="rounded-circle shadow-l bg-fade-red-dark" width="50">
						</div>
						
						<div class="ps-2 ms-1 align-self-center w-100">
							<h5 class="font-600 mb-0"><?php echo e($client->name); ?></h5>
							<p class="mt-n1 font-11 mb-0">
								<?php echo e($client->company_name); ?>

							</p>
							
								
									
						</div> 
					</div>
				</a>
								<div >
									
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
								

								
								<a href="<?php echo e(route('createproject' , $client->id)); ?>" class="btn btn-s mt-1 mb-2 btn-full  border-highlight  color-black text-uppercase font-900" >  <?php echo e(__('text.Add Project')); ?> </a>
	
								<?php endif; ?>
								</div>
							
					   
			   
				<div class="divider mb-4" style="background-color: #b6afaf"></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
               
     

                
           


		<?php if($clients  and $clients->hasPages() ): ?>
        <nav aria-label="pagination-demo">
            <ul class="pagination justify-content-center"  style="padding-right: 0px !important">
				<?php if($clients->onFirstPage()): ?>
                <li class="page-item">
                    <a class="page-link rounded-xs bg-highlight color-white border-0" href="#" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-right"></i></a>
                </li>
				<?php else: ?> 
				<li class="page-item">
                    <a class="page-link rounded-xs bg-highlight color-white border-0" href="<?php echo e($clients->previousPageUrl()); ?>" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-right"></i></a>
                </li>
				<?php endif; ?>

				<?php
					if($clients->lastPage() <5)
					$length=$clients->lastPage();
					else {
						$length=4;
					}
					
				?>
				<?php for($page = 1; $page <= $length; $page++): ?>
				<?php if($page == $clients->currentPage()): ?>
				<a class="page-link rounded-xs bg-highlight color-white border-0" href="#" tabindex="-1" aria-disabled="true"><?php echo e($page); ?></a>

				<?php else: ?>
				<li class="page-item"><a class="page-link rounded-xs bg-highlight color-white border-0" href="<?php echo e($clients->url($page)); ?>"><?php echo e($page); ?></a></li>

	
				<?php endif; ?>
			<?php endfor; ?>

			<?php if($clients->hasMorePages()): ?>
			<li class="page-item">
				<a class="page-link rounded-xs bg-highlight color-white border-0" href="<?php echo e($clients->nextPageUrl()); ?>" rel="next" ><i class="fa fa-angle-left"></i></a>

			</li>
		<?php else: ?>
			<li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
				<a class="page-link rounded-xs bg-highlight color-white border-0" href="#"><i class="fa fa-angle-left"></i></a>
			</li>
		<?php endif; ?>
			
                
            </ul>
        </nav>
<?php endif; ?>       
</div>
</div>
       
        <?php $__env->stopSection(); ?>




    
   



      
        <script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>

        <script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>

		
<script>
	$(document).ready(function(){
		var searchResult = document.getElementById('result');
		$('#search').on('keyup', function(){
				search();
			});
	
	   
		function search(){
			var searchResult = document.getElementById('result');
	
			$(searchResult).html('');
			 var keyword = $('#search').val();
			if(keyword != ''){
				searchResult.classList.remove('disabled-search-list');
	
				$.post('<?php echo e(route("clientsearch")); ?>',
				{
					_token: $('meta[name="csrf-token"]').attr('content'),
					keyword:keyword
				},
				function(data){
					console.log(data);
					show_result(data);
					
				});
			}    
		}
	
		
		// show result with ajax
		function show_result(data){
			$(searchResult).html('');
			if(data.results.length <= 0)
			{
			   $(searchResult).append(`<p><?php echo e(__('text.No Results')); ?></p>`);
			}
	
			else
			{
				for(let i = 0; i < data.results.length; i++){
					$( searchResult ).append( `<a href="https://localhost/haririapp/public/clients/` +data.results[i].id+     `/ " 
													   
					style="line-height: 70px;
					color: #1f1f1f;
					font-weight: 500;
					font-size: 13px;
					border-bottom: solid 1px rgba(0, 0, 0, 0.05);">
										<p><h5 class="font-500"> ` +data.results[i].name + `</h5>
										<h5 class="font-400">` +data.results[i].company_name +` </h5>    </p>                              
									</a> `);   
				}
			}
		}
	});
	</script>
	
	
	
		
		
		
   



        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/clients/index.blade.php ENDPATH**/ ?>