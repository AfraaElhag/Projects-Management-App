<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Profile')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    
        <div class="card card-style">
            <div class="content">
                <div class="d-flex row">
                    
                    <div class="col-6">
                        <h1 class="mb-0 pt-1"><?php echo e($user->name); ?></h1>
                        <p class="color-highlight font-11 mt-n2 mb-3">
                            <?php if( $user->role == 'admin'): ?>
                            <?php echo e(__('text.Admin')); ?>

                            <?php elseif($user->role == 'senior designer'): ?>
                            <?php echo e(__('text.Senior Designer')); ?>

                            <?php elseif($user->role == 'junior designer'): ?>
                            <?php echo e(__('text.Junior Designer')); ?>

                            <?php elseif($user->role == 'customer service'): ?>
                            <?php echo e(__('text.Customer Service')); ?>

                            <?php elseif($user->role == 'accountant'): ?>
                            <?php echo e(__('text.Accountant')); ?>

                            <?php elseif($user->role == 'Department manager'): ?>
                            <?php echo e(__('text.Department Manager')); ?>

                            <?php elseif($user->role == 'project manager'): ?>
                            <?php echo e(__('text.Project Manager')); ?>


                             <?php endif; ?>
                        </p>
                    </div>
                    <div class="col-6 text-end">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
                    <a href="#" class="btn btn-s mt-1 mb-2 btn-full  border-highlight rounded-s color-black  text-uppercase font-900  "
                    onclick="deletefun(<?php echo e($user->id); ?> , '<?php echo e(__('text.Continue')); ?>')" style="padding-left:4px !important; padding-right:4px !important; ">
                    <?php echo e(__('text.Delete User')); ?>

                        <form id="delete-form<?php echo e($user->id); ?>" action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form></a>
                    <?php endif; ?></div>
                </div>
                <p>
                </p>
           
        <form method="POST"  action="<?php echo e(route('users.update',[$user->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        
                <div class="input-style has-borders hnoas-icon input-style-always-active validate-field mb-4 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input autocomplete="off" value= "<?php echo e($user->name); ?>" type="name" class="form-control validate-name" id="form1" placeholder="<?php echo e(__('text.User Name')); ?>" name="name">
                    <label for="form1" class="color-highlight font-400 font-13"><?php echo e(__('text.User Name')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>
                </div>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <div class="input-style has-borders input-style-always-active validate-field no-icon mb-4 <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="form2" class="color-highlight font-400 font-13"><?php echo e(__('text.Role')); ?></label>
                    <select id="form2" name="role">
                        <option value="<?php echo e($user->role); ?>"  selected>
                            <?php if($user->role == 'admin'): ?>
                            <?php echo e(__('text.Admin')); ?>

                            <?php elseif($user->role == 'senior designer'): ?>
                            <?php echo e(__('text.Senior Designer')); ?>

                            <?php elseif($user->role == 'junior designer'): ?>
                            <?php echo e(__('text.Junior Designer')); ?>

                            <?php elseif($user->role == 'customer service'): ?>
                                <?php echo e(__('text.Customer Service')); ?>

                            <?php elseif($user->role == 'department manager'): ?>
                                <?php echo e(__('text.Department Manager')); ?>

                            <?php elseif($user->role == 'project manager'): ?>
                                <?php echo e(__('text.Project Manager')); ?>

                            <?php elseif($user->role == 'accountant'): ?>
                                <?php echo e(__('text.Accountant')); ?>

                            <?php endif; ?>

                           
                        </option>


                        <option value="admin"><?php echo e(__('text.Admin')); ?></option>
                        <option value="senior designer"><?php echo e(__('text.Senior Designer')); ?></option>
                        <option value="junior designer"><?php echo e(__('text.Junior Designer')); ?></option>
                        <option value="customer service"><?php echo e(__('text.Customer Service')); ?></option>
                        <option value="department manager"><?php echo e(__('text.Depatment Manager')); ?></option>
                        <option value="project manager"><?php echo e(__('text.Project Manager')); ?></option>
                        <option value="accountant"><?php echo e(__('text.Accountant')); ?></option>


                    </select>
                    <span><i class="fa fa-chevron-down"></i></span>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <i class="fa fa-check disabled invalid color-red-dark"></i>
                    <em></em>
                </div>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isCustomerService','isDesigner'])): ?>
                <div class="input-style has-borders input-style-always-active validate-field no-icon mb-4 <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input autocomplete="off" value="<?php echo e($user->role); ?>" type="name" class="form-control validate-email" id="form3" placeholder="<?php echo e(__('text.Role')); ?>" name="role" disabled>
                    <label for="form3" class="color-highlight font-400 font-13"><?php echo e(__('text.Role')); ?></label>
                </div>
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>

                
                <div class="input-style has-borders no-icon input-style-always-active validate-field mb-4 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input autocomplete="off" value="<?php echo e($user->email); ?>" type="email" class="form-control validate-email" id="form3" placeholder="<?php echo e(__('text.Email')); ?>" name="email">
                    <label for="form3" class="color-highlight font-400 font-13"><?php echo e(__('text.Email')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div class="input-style has-borders no-icon input-style-always-active validate-field mb-4 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input autocomplete="off" value="<?php echo e($user->phone); ?>" type="tel" class="form-control validate-tel" id="form4" placeholder="<?php echo e(__('text.Phone Number')); ?>" name="phone">
                    <label for="form4" class="color-highlight font-400 font-13"><?php echo e(__('text.Phone Number')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>
                </div>
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
   

                <div class="input-style has-borders no-icon input-style-always-active validate-field mb-4 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <input autocomplete="off" value="" type="passord" class="form-control validate-passord" id="form6" placeholder="******" name="password">
                    <label for="form6" class="color-highlight font-400 font-13"><?php echo e(__('text.Password')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn-center-xl mb-3 btn btn-m btn-full rounded-sm shadow-l border-highlight  color-black text-uppercase font-900 mt-4"><?php echo e(__('text.Save')); ?></button>
            </form>          
            </div>
        </div>
        
          

        
        
         

        

       
    <?php $__env->stopSection(); ?>

    <script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/users/edit.blade.php ENDPATH**/ ?>