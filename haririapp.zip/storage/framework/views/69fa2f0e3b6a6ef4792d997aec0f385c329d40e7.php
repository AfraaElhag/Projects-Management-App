<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Tasks List')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

          
        
        <div class="card card-style">
            <div class="content mt-1 mb-2">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php if($tasks->isEmpty()): ?>
                <div class=" mb-5 text-center mt-5 " style="height: 200px;vertical-align :middle ">
                    <h3 class="mt-5 mb-5">
                        <?php echo e(__('text.No Projects')); ?> </h3>
                </div>
                <?php else: ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('isAdmin')): ?>
                    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-m mt-4 mb-4 btn-full  border-highlight  color-black rounded-s text-uppercase font-900" ><?php echo e(__('text.Add New Task')); ?></a>

                    <?php endif; ?>
                    <h1 class="vcard-title text-capitalize font-18  color-highlight"><?php echo e(__('text.Milestone One')); ?></h1>
                    <?php $__currentLoopData = $tasks->where('milestone_number','1'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('tasks.edit', [$task->id])); ?>" class="color-highlight">

                        <div class="row mb-2">
                            <div class="col-6 ">
                              
                                    <img src="<?php echo e(asset('images/dot.png')); ?>" width="15"  height="15" class="">
                              
                             
                                <span class="font-14 has-icon"><?php echo e($task->task); ?></span>
                                

                               
                                
                            </div>
                            <div class="col-6 text-end">
                                
                                <?php if($task->responsible == 'senior designer'): ?>
                                <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Senior Designer')); ?></span>
                                <?php elseif($task->responsible == 'junior designer'): ?>
                                <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Junior Designer')); ?></span>
                                <?php elseif($task->responsible == 'admin'): ?>
                                <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> <?php echo e(__('text.Admin')); ?></span> 
                                <?php elseif($task->responsible == 'customer service'): ?>
                                <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Customer Service')); ?></span>
                                <?php elseif($task->responsible == 'Depatment manager'): ?>
                                <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Depatment Manager')); ?></span>
                                <?php elseif($task->responsible == 'project manager'): ?>
                                <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Project Manager')); ?></span>
                                <?php elseif($task->responsible == 'accountant'): ?>
                                <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Accountant')); ?></span>
                                <?php endif; ?>

                            </div>
                        </div>
                        
             
                        <div class="divider"></div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			    </div>
		    </div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight"><?php echo e(__('text.Milestone Two')); ?></h1>
                <?php $__currentLoopData = $tasks->where('milestone_number','2'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('tasks.edit', [$task->id])); ?>" class="color-highlight">

                    <div class="row mb-0">
                        <div class="col-6">
                            <img src="<?php echo e(asset('images/dot.png')); ?>" width="15"  height="15" class="">

                            <span class="font-14 has-icon"><?php echo e($task->task); ?></span>
                            
                        </div>
                        <div class="col-6 text-end">
                            <?php if($task->responsible == 'senior designer'): ?>
                            <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Senior Designer')); ?></span>
                            <?php elseif($task->responsible == 'junior designer'): ?>
                            <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Junior Designer')); ?></span>
                            <?php elseif($task->responsible == 'admin'): ?>
                            <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> <?php echo e(__('text.Admin')); ?></span> 
                            <?php elseif($task->responsible == 'customer service'): ?>
                            <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Customer Service')); ?></span>
                            <?php elseif($task->responsible == 'Depatment manager'): ?>
                            <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Depatment Manager')); ?></span>
                            <?php elseif($task->responsible == 'project manager'): ?>
                            <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Project Manager')); ?></span>
                            <?php elseif($task->responsible == 'accountant'): ?>
                            <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Accountant')); ?></span>
                            <?php endif; ?>

                        </div>
                    </div>

                  
                    <div class="divider"></div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight"><?php echo e(__('text.Milestone Three')); ?></h1>
                <?php $__currentLoopData = $tasks->where('milestone_number','3'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('tasks.edit', [$task->id])); ?>" class="color-highlight">

                    <div class="row mb-0">
                        <div class="col-6">
                            <img src="<?php echo e(asset('images/dot.png')); ?>" width="15"  height="15" class="">

                            <span class="font-14 has-icon"><?php echo e($task->task); ?></span>
                        </div>
                        <div class="col-6 text-end">
                            <?php if($task->responsible == 'senior designer'): ?>
                            <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Senior Designer')); ?></span>
                            <?php elseif($task->responsible == 'junior designer'): ?>
                            <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Junior Designer')); ?></span>
                            <?php elseif($task->responsible == 'admin'): ?>
                            <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> <?php echo e(__('text.Admin')); ?></span> 
                            <?php elseif($task->responsible == 'customer service'): ?>
                            <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Customer Service')); ?></span>
                            <?php elseif($task->responsible == 'Depatment manager'): ?>
                            <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Depatment Manager')); ?></span>
                            <?php elseif($task->responsible == 'project manager'): ?>
                            <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Project Manager')); ?></span>
                            <?php elseif($task->responsible == 'accountant'): ?>
                            <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Accountant')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="divider"></div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight"><?php echo e(__('text.Milestone Four')); ?></h1>
                <?php $__currentLoopData = $tasks->where('milestone_number','4'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('tasks.edit', [$task->id])); ?>" class="color-highlight">

                    <div class="row mb-0">
                        <div class="col-6">
                            
                            <img src="<?php echo e(asset('images/dot.png')); ?>" width="15"  height="15" class="">

                            <span class="font-14 has-icon"><?php echo e($task->task); ?></span>
                        </div>
                        <div class="col-6 text-end">
                            <?php if($task->responsible == 'senior designer'): ?>
                            <span class="badge bg-blue-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Senior Designer')); ?></span>
                            <?php elseif($task->responsible == 'junior designer'): ?>
                            <span class="badge bg-green-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Junior Designer')); ?></span>
                            <?php elseif($task->responsible == 'admin'): ?>
                            <span class="badge bg-red-dark text-uppercase   p-2 font-8" style="vertical-align: super;"> <?php echo e(__('text.Admin')); ?></span> 
                            <?php elseif($task->responsible == 'customer service'): ?>
                            <span class="badge bg-yellow-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Customer Service')); ?></span>
                            <?php elseif($task->responsible == 'Depatment manager'): ?>
                            <span class="badge bg-orange-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Depatment Manager')); ?></span>
                            <?php elseif($task->responsible == 'project manager'): ?>
                            <span class="badge bg-magenta-dark text-uppercase  p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Project Manager')); ?></span>
                            <?php elseif($task->responsible == 'accountant'): ?>
                            <span class="badge bg-yellow-dark text-uppercase   p-2 font-8" style="vertical-align: super;"><?php echo e(__('text.Accountant')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                  
                    <div class="divider"></div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                <?php endif; ?>
			</div>
		</div>
		
		
        
    
      
        <?php $__env->stopSection(); ?>

<script type="text/javascript" src="scripts/bootstrap.min.js"></script>
<script type="text/javascript" src="scripts/custom.js"></script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/tasks/index.blade.php ENDPATH**/ ?>