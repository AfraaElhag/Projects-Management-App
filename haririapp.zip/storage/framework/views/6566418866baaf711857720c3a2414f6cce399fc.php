<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($client->id); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($client->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($client->updated_at); ?></p>
</div>

<!-- Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($client->name); ?></p>
</div>

<!-- Email Field -->
<div class="col-sm-12">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo e($client->email); ?></p>
</div>

<!-- Company Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('company_name', 'Company Name:'); ?>

    <p><?php echo e($client->company_name); ?></p>
</div>

<!-- Address Field -->
<div class="col-sm-12">
    <?php echo Form::label('address', 'Address:'); ?>

    <p><?php echo e($client->address); ?></p>
</div>

<!-- Phone Field -->
<div class="col-sm-12">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <p><?php echo e($client->phone); ?></p>
</div>

<!-- Password Field -->
<div class="col-sm-12">
    <?php echo Form::label('password', 'Password:'); ?>

    <p><?php echo e($client->password); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/clients/show_fields.blade.php ENDPATH**/ ?>