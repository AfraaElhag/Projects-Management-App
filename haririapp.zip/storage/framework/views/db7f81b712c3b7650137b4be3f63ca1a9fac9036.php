<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
<title>Azures BootStrap</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/style.css')); ?>">
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/css/fontawesome-all.min.css')); ?>">    
<link rel="manifest" href="<?php echo e(asset('_manifest.json')); ?>" data-pwa-version="set_in_manifest_and_pwa_js">
<link rel="apple-touch-icon" sizes="180x180" href="app/icons/icon-192x192.png">
</head>
    
<body class="theme-light">
    
<div id="preloader"><div class="spinner-border color-highlight" role="status"></div></div>
    
<div id="page">
    
    <!-- header and footer bar go here-->
    <div class="header header-fixed header-auto-show header-logo-app">
        <a href="#" data-back-button class="header-title header-subtitle">Back to Pages</a>
        <a href="#" data-back-button class="header-icon header-icon-1"><i class="fas fa-arrow-left"></i></a>
        <a href="#" data-toggle-theme class="header-icon header-icon-2 show-on-theme-dark"><i class="fas fa-sun"></i></a>
        <a href="#" data-toggle-theme class="header-icon header-icon-2 show-on-theme-light"><i class="fas fa-moon"></i></a>
        <a href="#" data-menu="menu-highlights" class="header-icon header-icon-3"><i class="fas fa-brush"></i></a>
        <a href="#" data-menu="menu-main" class="header-icon header-icon-4"><i class="fas fa-bars"></i></a>
    </div>
    <div id="footer-bar" class="footer-bar-5">
        <a href="index-components.html"><i data-feather="heart" data-feather-line="1" data-feather-size="21" data-feather-color="red-dark" data-feather-bg="red-fade-light"></i><span>Features</span></a>
        <a href="index-media.html"><i data-feather="image" data-feather-line="1" data-feather-size="21" data-feather-color="green-dark" data-feather-bg="green-fade-light"></i><span>Media</span></a>
        <a href="index.html"><i data-feather="home" data-feather-line="1" data-feather-size="21" data-feather-color="blue-dark" data-feather-bg="blue-fade-light"></i><span>Home</span></a>
        <a href="index-pages.html" class="active-nav"><i data-feather="file" data-feather-line="1" data-feather-size="21" data-feather-color="brown-dark" data-feather-bg="brown-fade-light"></i><span>Pages</span></a>
        <a href="index-settings.html"><i data-feather="settings" data-feather-line="1" data-feather-size="21" data-feather-color="dark-dark" data-feather-bg="gray-fade-light"></i><span>Settings</span></a>
    </div>
    
    <div class="page-content">
        
        <div class="page-title page-title-small">
            <h2><a href="#" data-back-button><i class="fa fa-arrow-left"></i></a>Update Tasks</h2>
            <a href="#" data-menu="menu-main" class="bg-fade-highlight-light shadow-xl preload-img" data-src="images/avatars/5s.png"></a>
        </div>
        <div class="card header-card shape-rounded" data-card-height="150">
            <div class="card-overlay bg-highlight opacity-95"></div>
            <div class="card-overlay dark-mode-tint"></div>
            <div class="card-bg preload-img" data-src="images/pictures/20s.jpg"></div>
        </div>
		
		
		
		<div class="content mb-2">
			<h5 class="float-start font-16 font-500">Project Tasklist</h5>
			<a class="float-end font-12 color-highlight mt-n1" href="#">View All</a>
			<div class="clearfix"></div>
		</div>

		<form method="POST"  action="<?php echo e(route('updateprojecttasks',[$project->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

		<div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">Milestone 1</h1>
                <?php $__currentLoopData = $project->tasks->where('milestone_number','1'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="form-check icon-check">
                    <?php if($task->pivot->status == 'completed'): ?>
					<input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>" checked name="task_id[]">
					<?php else: ?>
                    <input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>"  name="task_id[]">
                    <?php endif; ?>
                    <label class="font-14 form-check-label" for="<?php echo e($task->id); ?>"><?php echo e($task->task); ?></label>
					<i class="font-17 icon-check-1 far fa-circle color-gray-dark"></i>
					<i class="font-17 icon-check-2 fa fa-check-circle color-green-dark"></i>
					<?php if($task->pivot->status == 'completed'): ?>
					<span class="badge bg-blue-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php else: ?>
                    <span class="badge bg-red-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php endif; ?>
                </div>
                <div class="divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">Milestone 2</h1>
                <?php $__currentLoopData = $project->tasks->where('milestone_number','2'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="form-check icon-check">
                    <?php if($task->pivot->status == 'completed'): ?>
					<input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>" checked name="task_id[]">
					<?php else: ?>
                    <input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>"  name="task_id[]">
                    <?php endif; ?>
                    <label class="font-14 form-check-label" for="<?php echo e($task->id); ?>"><?php echo e($task->task); ?></label>
					<i class="font-17 icon-check-1 far fa-circle color-gray-dark"></i>
					<i class="font-17 icon-check-2 fa fa-check-circle color-green-dark"></i>
					<?php if($task->pivot->status == 'completed'): ?>
					<span class="badge bg-blue-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php else: ?>
                    <span class="badge bg-red-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php endif; ?>
                </div>
                <div class="divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">Milestone 3</h1>
                <?php $__currentLoopData = $project->tasks->where('milestone_number','3'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="form-check icon-check">
                    <?php if($task->pivot->status == 'completed'): ?>
					<input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>" checked name="task_id[]">
					<?php else: ?>
                    <input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>"  name="task_id[]">
                    <?php endif; ?>
                    <label class="font-14 form-check-label" for="<?php echo e($task->id); ?>"><?php echo e($task->task); ?></label>
					<i class="font-17 icon-check-1 far fa-circle color-gray-dark"></i>
					<i class="font-17 icon-check-2 fa fa-check-circle color-green-dark"></i>
                    <?php if($task->pivot->status == 'completed'): ?>
					<span class="badge bg-blue-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php else: ?>
                    <span class="badge bg-red-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php endif; ?>
                
                </div>
                <div class="divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        <div class="card card-style">
			<div class="content mb-3">			
				<h1 class="vcard-title text-capitalize font-18  color-highlight">Milestone 4</h1>
                <?php $__currentLoopData = $project->tasks->where('milestone_number','4'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="form-check icon-check">
                    <?php if($task->pivot->status == 'completed'): ?>
					<input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>" checked name="task_id[]">
					<?php else: ?>
                    <input class="font-14 form-check-input" type="checkbox" value="<?php echo e($task->id); ?>" id="<?php echo e($task->id); ?>"  name="task_id[]">
                    <?php endif; ?>
                    <label class="font-14 form-check-label" for="<?php echo e($task->id); ?>"><?php echo e($task->task); ?></label>
					<i class="font-17 icon-check-1 far fa-circle color-gray-dark"></i>
					<i class="font-17 icon-check-2 fa fa-check-circle color-green-dark"></i>
					<?php if($task->pivot->status == 'completed'): ?>
					<span class="badge bg-blue-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php else: ?>
                    <span class="badge bg-red-dark text-uppercase float-end mt-2 p-1 font-8"><?php echo e($task->pivot->status); ?></span>
                    <?php endif; ?>
                </div>
                <div class="divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

        <button class="mb-3 btn btn-m btn-full rounded-sm shadow-l bg-blue-dark text-uppercase font-900 mt-4">Add Client</button>
        </form>
		
		
        
    
      
        <!-- footer and footer card-->
        <div class="footer" data-menu-load="<?php echo e(asset('/menu-footer')); ?>"></div>  
    </div>    
    <!-- end of page content-->
    
    
    <div id="menu-share" 
         class="menu menu-box-bottom menu-box-detached rounded-m" 
         data-menu-load="<?php echo e(asset('/menu-share')); ?>"
         data-menu-height="420" 
         data-menu-effect="menu-over">
    </div>    
    
    <div id="menu-highlights" 
         class="menu menu-box-bottom menu-box-detached rounded-m" 
         data-menu-load="<?php echo e(asset('/menu-colors')); ?>"
         data-menu-height="510" 
         data-menu-effect="menu-over">        
    </div>
    
    <div id="menu-main"
         class="menu menu-box-right menu-box-detached rounded-m"
         data-menu-width="260"
         data-menu-load="<?php echo e(asset('/menu-main')); ?>"
         data-menu-active="nav-pages"
         data-menu-effect="menu-over">  
    </div>
    

    
</div>    



<script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>

</body>
<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/editmilestone.blade.php ENDPATH**/ ?>