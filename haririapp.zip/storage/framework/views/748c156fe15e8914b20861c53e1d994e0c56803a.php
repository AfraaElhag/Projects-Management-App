<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($project->id); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($project->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($project->updated_at); ?></p>
</div>

<!-- Project Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('project_name', 'Project Name:'); ?>

    <p><?php echo e($project->project_name); ?></p>
</div>

<!-- Status Field -->
<div class="col-sm-12">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo e($project->status); ?></p>
</div>

<!-- Start Date Field -->
<div class="col-sm-12">
    <?php echo Form::label('start_date', 'Start Date:'); ?>

    <p><?php echo e($project->start_date); ?></p>
</div>

<!-- End Date Field -->
<div class="col-sm-12">
    <?php echo Form::label('end_date', 'End Date:'); ?>

    <p><?php echo e($project->end_date); ?></p>
</div>

<!-- Details Field -->
<div class="col-sm-12">
    <?php echo Form::label('details', 'Details:'); ?>

    <p><?php echo e($project->details); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\haririapp\resources\views/projects/show_fields.blade.php ENDPATH**/ ?>