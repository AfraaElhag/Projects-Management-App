<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['title' =>  __('text.Client Info')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
       

              
        <div class="card card-style">
            <div class="content mt-1 mb-2">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
             
                        <div class="row mt-3" style="">
                            <div class="col-4 " style="padding-left:4px !important; padding-right:4px !important; ">               
                            <a href="<?php echo e(route('createproject' , $client->id)); ?>" class="button rounded-s btn btn-s mt-1 mb-2 btn-full  border-highlight  color-black  text-uppercase font-900" style="padding-left:4px !important; padding-right:4px !important; "><?php echo e(__('text.Add Project')); ?></a>
                            </div>
                            <div class="col-4" style="padding-left:4px !important; padding-right:4px !important; ">
                                <a href="<?php echo e(route('clients.edit' , $client->id)); ?>"
                                     class="btn btn-s mt-1 mb-2 btn-full  border-highlight rounded-s color-black  text-uppercase font-900"
                                     style="padding-left:4px !important; padding-right:4px !important; "  > <?php echo e(__('text.Edit')); ?></a>
                        
                            </div>
                            <div class="col-4" style="padding-left:4px !important; padding-right:4px !important; ">
                                <a href="#" class="btn btn-s mt-1 mb-2 btn-full  border-highlight rounded-s color-black  text-uppercase font-900  "
                                onclick="deletefun(<?php echo e($client->id); ?> , '<?php echo e(__('text.Continue')); ?>')" style="padding-left:4px !important; padding-right:4px !important; ">
                                <?php echo e(__('text.Delete Client')); ?>

                                    <form id="delete-form<?php echo e($client->id); ?>" action="<?php echo e(route('clients.destroy',$client->id)); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form></a>
                        
                            </div>
                        </div>
                       
                     
                        
                    
                <?php endif; ?>
        
                
                <div class="vcard-field"><strong><?php echo e(__('text.Client Name')); ?></strong> <?php echo e($client->name); ?> <i class="fa fa-user "></i></div>               
                <div class="vcard-field"><strong><?php echo e(__('text.Company Name')); ?></strong><a href=""> <?php echo e($client->company_name); ?></a><i class="fa fa-suitcase "></i></div>               
                <div class="vcard-field line-height-l pb-3"><strong><?php echo e(__('text.Address')); ?></strong><a href=""> <?php echo e($client->address); ?></a><i class="fa fa-map-marker  mt-n2"></i></div>
            </div>
        </div>
        <div class="card card-style">
            <div class="content mt-3 mb-2">
                <h1 class="vcard-title text-capitalize font-18  "><?php echo e(__('text.Contacts')); ?></h1>

                <div class="vcard-field"><strong><?php echo e(__('text.Phone Number')); ?></strong><a href=""><?php echo e($client->phone); ?></a><i class="fa fa-phone "></i></div>
                <div class="vcard-field"><strong><?php echo e(__('text.Email')); ?></strong><a href=""><?php echo e($client->email); ?></a><i class="fa fa-home #"></i></div>
          
               </div>
        </div>
       
        <div class="card card-style">
            <div class="content mt-3 mb-2">
                <h1 class="vcard-title text-capitalize font-18   mb-4"><?php echo e(__('text.Projects')); ?></h1>
                  <?php $__currentLoopData = $client->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('projects.show', [$project->id])); ?>">
                <div class="d-flex mb-3">
                    <div class="align-self-center">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" width="50" height="70" class="">
                    </div>
                    <div class="ps-2 ms-1 align-self-center w-100">
                        <h5 class="font-600 mb-0"><?php echo e($project->project_name); ?></h5>
                        <h5 class="font-500 mb-1"><?php echo e($project->status); ?> %
                           

                          

                       <p><span class="font-10 color-highlight">
                        <?php if($project->status == '0'): ?>
                        <span class="badge bg-red-dark   mt-0 p-1 font-12 font-400"  ><?php echo e(__('text.Not Started')); ?></span>
                        <?php elseif($project->status == '100'): ?>
                    <span class="badge bg-red-dark   mt-0 p-1 font-12 font-400"  ><?php echo e(__('text.Completed Project')); ?></span>

                    <?php else: ?>
                    <span class="badge bg-red-dark   mt-0 p-1 font-12 font-400"  ><?php echo e(__('text.Inprogress')); ?></span>

                    <?php endif; ?>
                </span></p>
                        </h5>
								
					</div> 
				</div>
			</a>
                            <div >
                                
							<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isCustomerService'])): ?>
                          

							
							<a href="<?php echo e(route('projects.show',$project->id)); ?>" class="btn btn-s mt-1 mb-2 btn-full rounded-s  border-highlight  color-black text-uppercase font-900" ><?php echo e(__('text.More Info')); ?></a>

						


							<?php endif; ?>
                            </div>
                        
                   
           
            <div class="divider mb-3"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    
                   
            </div>
            
        </div>


       
        <?php $__env->stopSection(); ?>




    
   



      
<script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/clients/show.blade.php ENDPATH**/ ?>