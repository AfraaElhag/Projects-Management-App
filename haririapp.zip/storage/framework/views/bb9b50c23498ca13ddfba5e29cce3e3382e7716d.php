<?php $__env->startSection('content'); ?>
        
<?php echo $__env->make('layouts.header', ['title' => __('text.Alaa Hariri Office')  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        

     
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
       

        <div class="card card-style ">
            <div class="content mt-2 mb-0">
                <div class="menu-logo text-center mt-3 mb-3">
                    <a href="#"><img class=" " width="80" src="<?php echo e(asset('images/logo.png')); ?>"></a>
                </div>
                <div class="input-style no-borders has-icon validate-field mb-4 mt-5">
                    <i class="fa fa-user"></i>
                    <input autocomplete="off" type="email" class="form-control validate-name <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="form1a" placeholder="<?php echo e(__('text.Email')); ?>" name="email"
                    value="<?php echo e(old('email')); ?>" >
                    <label for="form1a" class="color-highlight font-10 mt-1"><?php echo e(__('text.Email')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>

                   
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
         

        
                
                <div class="input-style no-borders has-icon validate-field mb-4">
                    <i class="fa fa-lock"></i>
                    <input autocomplete="off" type="password" class="form-control validate-password <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="form3a" placeholder="<?php echo e(__('text.Password')); ?>" name="password">
                    <label for="form3a" class="color-highlight font-10 mt-1"><?php echo e(__('text.Password')); ?></label>
                    <i class="fa fa-times disabled invalid color-red-dark"></i>
                    <i class="fa fa-check disabled valid color-green-dark"></i>
                    <em>(<?php echo e(__('text.Required')); ?>)</em>

                   
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn-center-xl mb-3 btn btn-m btn-full rounded-sm shadow-l border-highlight  color-black text-uppercase font-900 mt-4"><?php echo e(__('text.Login')); ?></button>

               
            </form>

            
               
                <div class="divider mt-4 mb-3"></div>
            <!--
                <div class="d-flex mb-5">
                    <div class="w-50 font-11 pb-2 color-theme opacity-60 pb-3 text-end"><a href="<?php echo e(route('password.request')); ?>" class="color-theme"><?php echo e(__('text.Forgot Credentials')); ?></a></div>
                </div>
                -->
            </div>
            
        </div>

       
        <?php $__env->stopSection(); ?>




    
   



      
<script type="text/javascript" src="<?php echo e(asset('/scripts/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/scripts/custom.js')); ?>"></script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haririapp\resources\views/auth/login.blade.php ENDPATH**/ ?>